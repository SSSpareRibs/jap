package com.decoration.service;

/**
 * Created by dongchao on 2020/8/15 11:28
 */
public interface UserService {

    Integer addUser(String name);
}
