# decoration
# jsp跳转
http://localhost/decoration/toAddUser 
http://localhost/decoration/index.html

# ajax请求
http://localhost/decoration/addUser?name=123 

# mybatis自动生成代码使用
配置generatorConfig.xml，参考其中"t_user"表配置，右侧maven菜单中，选择plugins-->mybatis-generator->mybatis-generator:generate生成代码